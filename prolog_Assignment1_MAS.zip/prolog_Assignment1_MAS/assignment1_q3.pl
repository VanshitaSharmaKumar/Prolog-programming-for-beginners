summer(X):-
    happy(X).

warm(Y) :- 
    warm(Y).

summer(X):-
    warm(Y).   

warm(a).
happy(b).   