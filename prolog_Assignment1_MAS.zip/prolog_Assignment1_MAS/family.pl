child(john, sue).   child(john, sam).
child(jane, sue).   child(jane, sam).
child(sue, george). child(sue, gina).

male(john).  male(sam).    male(george).
female(sue). female(jane). female(june).

parent(Parent, Child) :-
    child(Child, Parent).

father(Father, Child) :-
    child(Child, Father),
    male(Father).

grand_father(GrandFather, Child) :-
    father(GrandFather, Father),
    parent(Father, Child).