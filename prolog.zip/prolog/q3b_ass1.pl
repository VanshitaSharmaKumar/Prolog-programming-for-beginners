warm(a).

warm(Y) :- 
    warm(Y).

summer(X):-
    happy(X).

summer(X):-
    warm(Y).

happy(b). 
