% QUESTION 6.1
%subtract(Y,0,Y).
%subtract(succ(X),succ(Y),(Z)):-
%    subtract(X,Y,Z).

%Question 6.2
subtract(0,Y,-(Y)).
subtract(Y,0,Y).
subtract(succ(X),succ(Y),(Z)):-
    subtract(X,Y,Z).


