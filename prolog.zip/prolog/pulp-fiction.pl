burger(X):-   
    bigMac(X).
burger(X):-  
    bigKahunaBurger(X).
burger(X):-   
    whopper(X).

bigMac(a).
bigMac(c).
bigKahunaBurger(b).
whopper(d).
eats(vincent,whopper).

enjoys(Person ,Burger) :-   
    not(bigKahunaBurger(Burger)) ; 
    eats(Person,Burger).  
    %burger(X).
    %eats(vincent,Burger).  

