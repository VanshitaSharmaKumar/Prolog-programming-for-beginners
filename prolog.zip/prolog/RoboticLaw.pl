scifi_Novel('I, Robot'). %declaring that I Robot is a scifi novel
film('I, Robot'). %I robot is a film
writes('Isaac_Asimov', 'I, Robot').
is_author('Isaac_Asimov').
%** First Law **
human('Mark').
robot(robot1).
harms(robot1,'Mark'). %robot harms Mark 
harmed('Mark').

%** Second Law *.
human('Mark').
robot(robot1).
obeys(robot1,'Mark'). %the robot obeys an order from mark 

%** Third Law **
human('Emma').
obeys(robot1,'Emma').
protects_itself(robot1).
protects(robot1, 'Emma').
%First law takes two positional arguments, Robot and Human. 
firstLaw(Robot, Human):- 
      robot(Robot),
      human(Human),
      not(harmed(Human)),
      not(harms(Robot,Human)).

%Second law takes two positional arguments
secondLaw(Robot,Human):-
    robot(Robot),
    human(Human),
    obeys(Robot,Human),
    firstLaw(Robot,Human).


%Third law takes two positional arguments
thirdLaw(Robot,Human):- 
    robot(Robot),
    human(Human),
    protects(Robot,Human),
    protects_itself(Robot),
    secondLaw(Robot, Human),
    firstLaw(Robot, Human).


