:-dynamic
% add declarations of predicates used in the agent program here. 
	in/1,			% matches the in/1 percept
	state/1,		% matches the state/1 percept
	zone/3,
	at/1,
	holding/1,
	goToBlock/1,			% send on change
	atBlock/1,		% send always
	color/2,		% send always 
	block/3,		% block(BlockID, ColorID, PlaceID).
	sequenceIndex/1,	% sequenceIndex(Index).
	place/1,	 	% place(PlaceID), send once 	
	sequence/1.
				% matches the zone/3 percept
% predicate sequence([ColorID])
%sequence([Blue,Green,Red,White,Blue]).
% A room is a place with exactly one neighbour, i.e., there is only one way to get to and from that place.
room(PlaceID) :- zone(_,PlaceID,Neighbours), length(Neighbours,1).